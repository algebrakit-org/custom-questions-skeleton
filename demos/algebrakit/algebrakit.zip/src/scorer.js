/*globals LearnosityAmd*/
import Scorer from './scorer/index';

LearnosityAmd.define([], function () {
    return {
        Scorer
    };
});
